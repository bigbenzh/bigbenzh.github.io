﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MessagePack.ImmutableCollection")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("fe5a979e-24c6-47dd-919f-81df6fb2e160")]
[assembly: AssemblyVersion("1.7.3.4")]
[assembly: AssemblyFileVersion("1.7.3.4")]
