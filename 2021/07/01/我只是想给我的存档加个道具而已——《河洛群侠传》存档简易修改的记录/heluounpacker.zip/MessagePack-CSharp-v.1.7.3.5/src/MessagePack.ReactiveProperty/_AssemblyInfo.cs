﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MessagePack.ReactiveProperty")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("16b0640a-c86d-4f21-bf2f-45efc728ae96")]
[assembly: AssemblyVersion("1.7.3.4")]
[assembly: AssemblyFileVersion("1.7.3.4")]
