﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MessagePack.UnityShims")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("4b074f49-f7cb-4885-9a58-cc75a7d64b62")]
[assembly: AssemblyVersion("1.7.3.4")]
[assembly: AssemblyFileVersion("1.7.3.4")]
