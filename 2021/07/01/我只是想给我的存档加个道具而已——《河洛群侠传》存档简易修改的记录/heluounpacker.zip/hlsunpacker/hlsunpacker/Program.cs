﻿using System;
using System.IO;
using System.Collections;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using saveunpacker;
namespace hlsunpacker
{
    class Program
    {
        static void Main(string[] args)
        {
            //print arguments
            if (args.Length<1)
            {
                Console.WriteLine("valid argument: split,combine,compress,uncompress");
                return;
            }
            for (int i = 0; i < args.Length; i++)
            {
                //Console.WriteLine(args[i]);

            }
            string f, pf,f2,f3,pf2,pf3;
            //switch actions
            string path = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);


            switch (args[0]){
                case "split":
                    f = args[1];
                    pf = Path.Combine(path, f);
                    Console.WriteLine(pf);
                    unpacksave_bnd.split_file(pf);
                    break;

                case "combine":
                    f = args[1];
                    f2 = args[2];
                    f3 = args[3];
                    pf = Path.Combine(path, f);
                    pf2 = Path.Combine(path, f2);
                    pf3 = Path.Combine(path, f3);
                    unpacksave_bnd.combine_file(pf,pf2,pf3);
                    break;

                case "compress":
                    f = args[1];
                    pf = Path.Combine(path, f);
                    unpacksave_bnd.compress_file(pf);
                    break;
                case "uncompress":
                    f = args[1];
                    pf = Path.Combine(path, f);
                    unpacksave_bnd.uncompress_file(pf);
                    break;
                case "decompress":
                    f = args[1];
                    pf = Path.Combine(path, f);
                    unpacksave_bnd.uncompress_file(pf);
                    break;

                default:
                    Console.WriteLine("error parameter");
                    break;
            }
            //unpacksave_bnd.save_struct d = unpacksave_bnd.loadfile(pf);
            //unpacksave_bnd.split_file(pf);
            //byte[] b;

            //manipulate savedata
            
            //unpacksave_bnd.combine_file(pf + ".header", pf +".gamedata", pf + ".recombined");
            // "Manual012.save" and "Manual012.save.recombined" should be the same



            //string f2 = "hack.save";
            //pf = Path.Combine(path, f2);
            //unpacksave_bnd.savefile(d, pf);

            //Console.WriteLine(Encoding.UTF8.GetString(d.save_header, 0, 9));
            

        }
    }
}
