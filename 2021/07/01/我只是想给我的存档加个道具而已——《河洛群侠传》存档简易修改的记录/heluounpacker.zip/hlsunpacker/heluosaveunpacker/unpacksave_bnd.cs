﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using MessagePack;
using MessagePack.LZ4;
using MessagePack.Internal;
using System.IO;
using Heluo.Data;
namespace saveunpacker
{
    public class unpacksave_bnd
    {
        const int NotCompressionSize = 64;
        const sbyte ExtensionTypeCode = 99;
        public class save_struct
        {
            public byte[] save_header;
            public byte[] encrypted_heluo_1_0_header;
            public byte[] encrypted_gamedata;
        }

        public static save_struct deconstruct_save(Stream fs)
        {
            save_struct d = new save_struct();
         
            long file_length = fs.Length;
            // read save_header
            d.save_header = new byte[9];
            fs.Read(d.save_header, 0, d.save_header.Length);

            //read heluo_header
            LZ4MessagePackSerializer.Deserialize<Header_HELUO_1_0>(fs, HeluoResolver.Instance, true);
            d.encrypted_heluo_1_0_header = new byte[fs.Position-9];
            fs.Position = 9;
            fs.Read(d.encrypted_heluo_1_0_header, 0, d.encrypted_heluo_1_0_header.Length);

            //read gamedata
            //gamedata is not able to read directly by Deserialize
            d.encrypted_gamedata = new byte[file_length - fs.Position];
            fs.Read(d.encrypted_gamedata, 0, d.encrypted_gamedata.Length);
            
            return d;
        }

        public static save_struct loadfile(string filename){
            save_struct d;
            //using(FileStream fs = new FileStream(Assembly.GetEntryAssembly().Location + filename, FileMode.Open)){
            using (FileStream fs = new FileStream(filename, FileMode.Open))
            {
                d = deconstruct_save(fs);
            }
            return d;
        }

        public static byte[] build_save(save_struct save)
        {
            long length = 0;
            length = save.save_header.Length + save.encrypted_heluo_1_0_header.Length + save.encrypted_gamedata.Length;
            long offset = 0;
            byte[] sb;
            using (MemoryStream st = new MemoryStream())
            {
                st.Write(save.save_header, 0, save.save_header.Length);
                st.Write(save.encrypted_heluo_1_0_header, 0, save.encrypted_heluo_1_0_header.Length);
                st.Write(save.encrypted_gamedata, 0, save.encrypted_gamedata.Length);
                st.Position = 0;
                sb = st.ToArray();
            }
            return sb;

            /*
            Array.Copy(save.save_header, 0, sb, offset, save.save_header.Length);
            offset += save.save_header.Length;
            Array.Copy(save.encrypted_heluo_1_0_header, 0, sb, offset, save.encrypted_heluo_1_0_header.Length);
            offset += save.encrypted_heluo_1_0_header.Length;
            Array.Copy(save.encrypted_gamedata, 0, sb, offset, save.encrypted_gamedata.Length);
            offset += save.encrypted_gamedata.Length;
            */
        }

        public static void savefile(save_struct save, string filename)
        {
            byte[] saveb = build_save(save);
            using (FileStream fs = new FileStream(filename, FileMode.Create))
            {
                fs.Write(saveb, 0, saveb.Length);
            }
            return;
        }

        public static void split_file(string input)
        {
            save_struct s = loadfile(input);
            string output1 = input + ".header";
            string output2 = input + ".gamedata";

            using (FileStream fs = new FileStream(output1, FileMode.Create))
            {
                fs.Write(s.save_header, 0, s.save_header.Length);
                fs.Write(s.encrypted_heluo_1_0_header, 0, s.encrypted_heluo_1_0_header.Length);
            }
            using (FileStream fs = new FileStream(output2, FileMode.Create))
            {
                fs.Write(s.encrypted_gamedata, 0, s.encrypted_gamedata.Length);
            }
            return;
        }

        public static void combine_file(string input1,string input2,string output)
        {
            FileStream ns = new FileStream(output, FileMode.Create);
            using (FileStream fs = new FileStream(input1, FileMode.Open))
            {
                fs.CopyTo(ns);
            }
            using (FileStream fs = new FileStream(input2, FileMode.Open))
            {
                fs.CopyTo(ns);
            }
            ns.Close();
            return;
        }

        public static void uncompress_file(string filename)
        {
            byte[] b;
            using (FileStream fs = new FileStream(filename, FileMode.Open))
            {
                MemoryStream ms = new MemoryStream();
                fs.CopyTo(ms);
                b = LZ4decompress(ms.ToArray());
            }
            using (FileStream fs = new FileStream(filename, FileMode.Create))
            {
                fs.Write(b, 0, b.Length);
            }
            return;
        }

        public static void compress_file(string filename)
        {
            Byte[] b;
            using (FileStream fs = new FileStream(filename, FileMode.Open))
            {
                MemoryStream ms = new MemoryStream();
                fs.CopyTo(ms);
                b = LZ4compress(ms.ToArray());
            }
            using (FileStream fs = new FileStream(filename, FileMode.Create))
            {
                fs.Write(b, 0, b.Length);
            }
            return;
        }



        public static byte[] LZ4decompress(byte[] data)
        {
            ArraySegment<byte> serializedData = new ArraySegment<byte>(data,0,data.Length);
            int readSize;
            var bytes = serializedData;
            if (MessagePackBinary.GetMessagePackType(bytes.Array, bytes.Offset) == MessagePackType.Extension)
                {
                    //Debug.Log(("reached 1");
                    var header = MessagePackBinary.ReadExtensionFormatHeader(bytes.Array, bytes.Offset, out readSize);
                    if (header.TypeCode == ExtensionTypeCode)
                    {
                        //Debug.Log(("reached 2");
                        // decode lz4
                        //Debug.Log(("readSize = "+readSize);
                        var offset = bytes.Offset + readSize;
                        //Debug.Log(("offset = "+offset);
                        var length = MessagePackBinary.ReadInt32(bytes.Array, offset, out readSize);
                        offset += readSize;
                        //Debug.Log(("readSize = "+readSize);
                        //Debug.Log(("offset = "+offset);
                        var buffer = LZ4MemoryPool.GetBuffer(); // use LZ4 Pool
                        if (buffer.Length < length)
                        {
                            buffer = new byte[length];
                        }

                        // LZ4 Decode
                        var len = bytes.Count + bytes.Offset - offset;
                        //Debug.Log((offset);
                        //Debug.Log((bytes.Offset);
                        LZ4Codec.Decode(bytes.Array, offset, len, buffer, 0, length);
                        //Debug.Log(("succeed");
                        return buffer;
                        //return formatter.Deserialize(buffer, 0, resolver, out readSize);
                    }
                }
            return null;
        }

        public static byte[] LZ4compress(byte[] data)
        // modified: changed return type from ArraySegment to Byte[]
        {
            ArraySegment<byte> serializedData = new ArraySegment<byte>(data,0,data.Length);
            if (serializedData.Count < NotCompressionSize)
            {
                return serializedData.Array;
            }
            else
            {
                var offset = 0;
                var buffer = LZ4MemoryPool.GetBuffer();
                var maxOutCount = LZ4Codec.MaximumOutputLength(serializedData.Count);
                if (buffer.Length < 6 + 5 + maxOutCount) // (ext header size + fixed length size)
                {
                    buffer = new byte[6 + 5 + maxOutCount];
                }

                // acquire ext header position
                var extHeaderOffset = offset;
                offset += (6 + 5);

                // write body
                var lz4Length = LZ4Codec.Encode(serializedData.Array, serializedData.Offset, serializedData.Count, buffer, offset, buffer.Length - offset);

                // write extension header(always 6 bytes)
                extHeaderOffset += MessagePackBinary.WriteExtensionFormatHeaderForceExt32Block(ref buffer, extHeaderOffset, (sbyte)ExtensionTypeCode, lz4Length + 5);

                // write length(always 5 bytes)
                MessagePackBinary.WriteInt32ForceInt32Block(ref buffer, extHeaderOffset, serializedData.Count);
                /*
                byte[] end = new byte[16];
                Array.Clear(end,0,end.Length);
                long index = System.Array.IndexOf(buffer,end);
                byte[] shortened_result = new byte[index];
                Array.Copy(buffer,0,shortened_result ,0, index);
                return new ArraySegment<byte>(shortened_result, 0, 6 + 5 + lz4Length);
                */
                return new ArraySegment<byte>(buffer, 0, 6 + 5 + lz4Length).Array;
            }
        }

    }

}
