﻿using System;
using MessagePack;
using MessagePack.Formatters;
using MessagePack.Resolvers;


namespace Heluo.Data
{
	// Token: 0x02000E23 RID: 3619
	internal class HeluoResolver : IFormatterResolver
	{
		// Token: 0x060069A2 RID: 27042 RVA: 0x00039AB8 File Offset: 0x00037CB8
		public IMessagePackFormatter<T> GetFormatter<T>()
		{
			return HeluoResolver.FormatterCache<T>.formatter;
		}

		// Token: 0x040045D5 RID: 17877
		public static IFormatterResolver Instance = new HeluoResolver();

		// Token: 0x040045D6 RID: 17878
		private static readonly IFormatterResolver[] resolvers = new IFormatterResolver[]
		{
			NativeDateTimeResolver.Instance,
			ContractlessStandardResolver.Instance
		};

		// Token: 0x02000E24 RID: 3620
		private static class FormatterCache<T>
		{
			// Token: 0x060069A5 RID: 27045 RVA: 0x00195E18 File Offset: 0x00194018
			static FormatterCache()
			{
				for (int i = 0; i < HeluoResolver.resolvers.Length; i++)
				{
					IMessagePackFormatter<T> messagePackFormatter = HeluoResolver.resolvers[i].GetFormatter<T>();
					if (messagePackFormatter != null)
					{
						HeluoResolver.FormatterCache<T>.formatter = messagePackFormatter;
						return;
					}
				}
			}

			// Token: 0x040045D7 RID: 17879
			public static readonly IMessagePackFormatter<T> formatter;
		}
	}

}