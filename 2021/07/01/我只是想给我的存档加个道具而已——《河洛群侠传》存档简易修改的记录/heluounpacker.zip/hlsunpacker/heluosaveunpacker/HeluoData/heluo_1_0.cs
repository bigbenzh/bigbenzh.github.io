﻿using System;
using System.Collections.Generic;
namespace Heluo.Data
{
	// Token: 0x02000E22 RID: 3618
	public struct Header_HELUO_1_0
	{
		// Token: 0x040045CC RID: 17868
		public DateTime saveTime;

		// Token: 0x040045CD RID: 17869
		public TimeSpan playedTime;

		// Token: 0x040045CE RID: 17870
		public int playedDays;

		// Token: 0x040045CF RID: 17871
		public string trackedQuestId;

		// Token: 0x040045D0 RID: 17872
		public string modName;

		// Token: 0x040045D1 RID: 17873
		public string modId;

		// Token: 0x040045D2 RID: 17874
		public List<string> teammateNames;

		// Token: 0x040045D3 RID: 17875
		public GameDifficulty difficulty;

		// Token: 0x040045D4 RID: 17876
		public byte[] screenShotData;
	}
}