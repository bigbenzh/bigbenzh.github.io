﻿using System;


namespace Heluo.Data
{
	// Token: 0x02000E1D RID: 3613
	public enum GameDifficulty
	{
		// Token: 0x0400455F RID: 17759
		Easy,
		// Token: 0x04004560 RID: 17760
		Normal,
		// Token: 0x04004561 RID: 17761
		Hard,
		// Token: 0x04004562 RID: 17762
		Master,
		// Token: 0x04004563 RID: 17763
		None
	}
}