import clr
import msgpack
clr.AddReference("heluosaveunpacker")
clr.AddReference("System")
from saveunpacker import unpacksave_bnd
from System.IO import MemoryStream
from System import Array,Byte

def patch(gamedata):
    b=msgpack.unpackb(gamedata)
    #加入古开明王城图
    b['Character']['Player']['Inventory'].append({"ItemId":"it801069","Count":1,"Durability":0,"MaxDurability":0,"Weight":0,"EffectId":[],"IsNew":True,"Stolen":False,"Level":0,"Hurt":{},"HurtDifference":0.0,"ForgeMaterials":{},"QualityTitle":"","QuenchHoleCount":0,"QuenchEffect":[],"ReforgeType":-1,"Id":None})
    c=msgpack.packb(b,use_bin_type=True,use_single_float=True)
    return c

if __name__ == "__main__":
    import sys
    if len(sys.argv) <=1:
        print("usage: patch_file.exe [Manual001.save]")
    filename = sys.argv[1]

a=unpacksave_bnd.loadfile(filename)
gamedata = a.encrypted_gamedata
raw_gamedata = unpacksave_bnd.LZ4decompress(gamedata)
raw_data=patch(bytes(raw_gamedata))
#c_data = Array[Byte](raw_data)
enc_gdata = bytes(unpacksave_bnd.LZ4compress(raw_data))
a.encrypted_gamedata = enc_gdata[:enc_gdata.index(b"\x00"*16)]
unpacksave_bnd.savefile(a,filename)
